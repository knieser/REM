rm(list=ls())
setwd("~/Documents/Research/Software/REM/R_package")

sessionInfo()

library(devtools)

# load from github.com
devtools::install_github('knieser/REM/R_package')

library(REMLA)
library(lavaan)


# Holzinger data
HS.full <- HolzingerSwineford1939
HS.df <- HolzingerSwineford1939[,c("x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9")]
HS.model <-  'visual  =~ x1 + x2 + x3
              textual =~ x4 + x5 + x6
              speed   =~ x7 + x8 + x9'


### EFA tests ###

# test case when data contains no-numeric entries
efa_results <- REM_EFA(X = HS.full, delta = 0, k_range = 2)

# test when delta < 0
efa_results <- REM_EFA(X = HS.df, delta = -1, k_range = 2)

# test when delta > 1
efa_results <- REM_EFA(X = HS.df, delta = 10, k_range = 2)

# test when k_range < 1
efa_results <- REM_EFA(X = HS.df, delta = 0.05, k_range = 0)

# test when k_range < 1 AND delta is < 0
efa_results <- REM_EFA(X = HS.df, delta = -10, k_range = 0)

# test when k_range < 1 AND delta is > 1
efa_results <- REM_EFA(X = HS.df, delta = 10, k_range = 0)

# test when k_range is non-integer
efa_results <- REM_EFA(X = HS.df, delta = 10, k_range = 0.3)


### CFA tests ###

# test case when data contains non-numeric columns
model_CFA = REM_CFA(X = HS.full, delta = 0.05, model = HS.model)

# test case when dimension of model does not match dimension of data
model_CFA = REM_CFA(X = HS.df[,-1], delta = 0.05, model = HS.model)

# test case when delta < 0
model_CFA = REM_CFA(X = HS.df, delta = -0.05, model = HS.model)

# test case when delta > 1
model_CFA = REM_CFA(X = HS.df, delta = 1.05, model = HS.model)

# test case when order of variables in the model are scrambled
HS.model2 <-  'visual  =~ x1 + x2 + x3
              speed   =~ x7 + x8 + x9
              textual =~ x4 + x5 + x6'
model_CFA2 = REM_CFA(X = HS.df, delta = 0.05, model = HS.model2)


# test case with not enough spacing between variables
HS.model3 <-  'visual  =~ x1 +x2 + x3
              speed   =~ x7 + x8 + x9
              textual =~ x4 + x5 + x6'
model_CFA3 = REM_CFA(X = HS.df, model = HS.model3)

# test case with unexpected model form
HS.model4 <-  'visual  =~ x1 + 2 x2 + x3
              speed   =~ x7 + x8 + x9
              textual =~ x4 + x5+ x6'
model_CFA4 = REM_CFA(X = HS.df, model = HS.model4)


# Run examples

# fit REM EFA
REM.EFA.fit <- REM_EFA(HS.df, k_range = 2:3, ctrREM = controlREM(steps = 5))

# REM EFA: 191.08 sec elapsed

lavaan.efa.fit <- efa(HS.df, 1:3, rotation = 'oblimin')
sqrt(diag(lavaan.efa.fit$nf1@vcov$vcov))
summary(lavaan.efa.fit)

# fit REM CFA
REM.CFA.fit <- REM_CFA(HS.df, model = HS.model, ctrREM = controlREM(steps = 5))
summary(REM.CFA.fit)

#     Intercept Factor 1 Factor 2 Factor 3 Res Var
# x1     5.009    0.824    0.000    0.000   0.320
# x2     5.724    0.359    0.000    0.000   0.871
# x3     2.056    0.499    0.000    0.000   0.751
# x4     2.885    0.000   -0.843    0.000   0.289
# x5     3.548    0.000   -0.871    0.000   0.242
# x6     2.260    0.000   -0.840    0.000   0.294
# x7     3.893    0.000    0.000    0.635   0.597
# x8     5.850    0.000    0.000    0.752   0.434
# x9     5.741    0.000    0.000    0.654   0.573

# robust sandwich variance estimator
tic('robust SEs')
se.robust <- SE(HS.df, REM.CFA.fit)
toc()
# robust SEs: 25.69 sec elapsed
se.robust

# bootstrap SEs
tic('bootstrap SEs')
se.boot <- SE(HS.df, REM.CFA.fit, 'bootstrap')
toc()
se.boot


# compare to lavaan
fit1 <- cfa(HS.model, data = HS.df)
fit2 <- cfa(HS.model, data = HS.df, std.ov = T)
fit3 <- cfa(HS.model, data = HS.df, std.ov = T, std.lv = T)

# expected, h1 structured
fit.robust1 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T)

# expected, h1 unstructured
fit.robust2 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T,
                   h1.information = 'unstructured')

# observed, numerical, h1 structured
fit.robust3 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T,
                   information = 'observed')

# observed, numerical, h1 unstructured
fit.robust4 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T,
                   information = 'observed', h1.information = 'unstructured')

# observed, analytic, h1 structured
fit.robust5 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T,
                   information = 'observed', observed.information = 'h1')

# observed, analytic, h1 unstructured
fit.robust6 <- cfa(HS.model, data = HS.df, se = 'robust', std.ov = T, std.lv = T,
                   information = 'observed', observed.information = 'h1', h1.information = 'unstructured')

fit1.se = summary(fit1)$pe$se[-c(19:21)]
fit2.se = summary(fit2)$pe$se[-c(19:21)]
fit3.se = summary(fit3)$pe$se[-c(19:21)]
robust1.se = summary(fit.robust1)$pe$se[-c(19:21)]
robust2.se = summary(fit.robust2)$pe$se[-c(19:21)]
robust3.se = summary(fit.robust3)$pe$se[-c(19:21)]
robust4.se = summary(fit.robust4)$pe$se[-c(19:21)]
robust5.se = summary(fit.robust5)$pe$se[-c(19:21)]
robust6.se = summary(fit.robust6)$pe$se[-c(19:21)]

# se.comparison <-
#   data.frame(fit1.se, fit2.se, fit3.se, robust1.se, robust2.se, robust3.se,
#       robust4.se, robust5.se, robust6.se,
#       c(REM.CFA.fit$EM_output$lambda.se,
#         REM.CFA.fit$EM_output$psi.se,
#         REM.CFA.fit$EM_output$phi.se))

se.comparison <-
  data.frame(lavaan.se = robust4.se,
             REM.se = c(REM.CFA.fit$EM_output$lambda.se,
               REM.CFA.fit$EM_output$psi.se,
               REM.CFA.fit$EM_output$phi.se))


# weighted lavaan estimate
# quick way to guess at REM standard errors
weights = REM.CFA.fit$REM_output$weights
HS.df$weights = weights
fit.weights <- cfa(HS.model, data = HS.df, sampling.weights = 'weights'
                   #se = 'robust', std.ov = T, std.lv = T,
                   #information = 'observed', h1.information = 'unstructured'
                   )
summary(fit.weights)


fit.bootstrap <- cfa(HS.model, data = HS.df, se = 'bootstrap')
standardizedsolution(fit.bootstrap)


# Hand calculating expected information matrix
library(matrixcalc)
constraints <- constraints(HS.model, colnames(HS.df))
mu = REM.CFA.fit$EM_output$mu
lambda = REM.CFA.fit$EM_output$lambda
psi = REM.CFA.fit$EM_output$psi
phi = REM.CFA.fit$EM_output$phi
sigma = lambda %*% phi %*% t(lambda) + diag(psi)
tau <- as.numeric(c(lambda[constraints==1], psi, phi[lower.tri(phi)]))
theta = c(mu, tau)

df = HS.df
n = nrow(df)
p = nrow(sigma)
k = ncol(lambda)
inv.sigma = solve(sigma)
Dp = duplication.matrix(p)
Dk = duplication.matrix(k)
Lp = elimination.matrix(p)
K = commutation.matrix(p,k)
lambda.idx = which(constraints==1)
C = matrix(data = 0, nrow = length(lambda.idx), ncol = p*k)
for(i in 1:length(lambda.idx)){C[i, lambda.idx[i]] <- 1}
A = matrix(data = 0, nrow = k*(k-1)/2, ncol = k*(k+1)/2)
A[1,2] <- 1
A[2,3] <- 1
A[3,5] <- 1
B = matrix(data = 0, nrow = p, ncol = p^2)
for(i in 1:p){B[i, 1 + (p+1)*(i-1)] <- 1}

W = 0.5 * t(Dp)%*%kronecker(inv.sigma, inv.sigma)%*%Dp

d.lambda = kronecker(diag(p), lambda %*% phi) %*% K + kronecker(lambda %*% phi, diag(p))
d.lambda.rest = d.lambda %*% t(C)
d.phi = kronecker(lambda, lambda) %*% Dk %*% t(A)
d.psi = t(B)
d.sigma = Lp %*% cbind(d.lambda.rest, d.psi, d.phi)

expected.info = t(d.sigma) %*% W %*% d.sigma
est.cov = solve(expected.info)/n
expected.info.se = round(sqrt(diag(est.cov)),3)


# scale parameters to match variance of the original data set
total.var = apply(HS.df, 2, var)
lambda.x = apply(lambda, 2, function(y) y*sqrt(total.var))
psi.x = psi * total.var
sigma.x = lambda.x %*% phi %*% t(lambda.x) + diag(psi.x)
inv.sigma.x = solve(sigma.x)
mu.se = sqrt(diag(inv.sigma.x)/n)


# estFUN.EM <- function(data, constraints){
#   mu = apply(data, 2, mean)
#   n = nrow(data)
#   p = ncol(data)
#   k = ncol(constraints)
#   #Dp = duplication.matrix(p)
#   #Dk = duplication.matrix(k)
#   #Lp = elimination.matrix(p)
#   #K = commutation.matrix(p,k)
#   lambda = matrix(0, nrow = p, ncol = k)
#   phi = matrix(0, nrow = k, ncol = k)
#   lambda.idx = which(constraints==1)
#   lambda.parms = length(lambda.idx)
#   #A = matrix(data = 0, nrow = k*(k-1)/2, ncol = k*(k+1)/2)
#   #A[1,2] <- 1
#   #A[2,3] <- 1
#   #A[3,5] <- 1
#   #B = matrix(data = 0, nrow = p, ncol = p^2)
#   #for(i in 1:p){B[i, 1 + (p+1)*(i-1)] <- 1}
#   #C = matrix(data = 0, nrow = length(lambda.idx), ncol = p*k)
#   #for(i in 1:length(lambda.idx)){C[i, lambda.idx[i]] <- 1}
#
#   d.lambda = matrix(0, nrow = n, ncol = lambda.parms)
#   d.psi = matrix(0, nrow = n, ncol = p)
#   d.phi = matrix(0, nrow = n, ncol = k*(k-1)/2)
#
#   function(theta){
#     mu = theta[1:p]
#     lambda.est = theta[(p+1):(p+lambda.parms)]
#     lambda[lambda.idx] <- lambda.est
#     psi = theta[(p+lambda.parms+1):(p+lambda.parms+p)]
#     phi.tri = theta[(p+lambda.parms+p+1):(p+lambda.parms+p+k*(k-1)/2)]
#     diag(phi) <- 1
#     phi[lower.tri(phi)] <- phi.tri
#     phi[upper.tri(phi)] <- phi.tri
#
#     # common expression used in estimating equations
#     Z = apply(data, 1, function(y) y - mu)
#     sigma = lambda %*% phi %*% t(lambda) + diag(psi)
#     inv.sigma = solve(sigma)
#
#     #W = 0.5 * t(Dp) %*% kronecker(inv.sigma, inv.sigma) %*% Dp
#     d.mu = t(inv.sigma %*% Z)
#     for (i in 1:n){
#       D = inv.sigma %*% (diag(p) - Z[,i] %*% t(Z[,i]) %*% inv.sigma)
#       d.lambda[i,] = -(D %*% lambda %*% phi)[lambda.idx]
#       d.psi[i,] = -0.5*diag(D)
#       d.phi[i,] = -(t(lambda) %*% D %*% lambda)[lower.tri(phi)]
#     }
#
#     # estimating equations
#     # score function for each person and parameter
#     c(d.mu, d.lambda, d.psi, d.phi)
#
#     #d.lambda = kronecker(diag(p), lambda %*% phi) %*% K + kronecker(lambda %*% phi, diag(p))
#     #d.lambda.rest = d.lambda %*% t(C)
#     #d.psi = t(B)
#     #d.phi = kronecker(lambda, lambda) %*% Dk %*% t(A)
#     #d.sigma = Lp %*% cbind(d.lambda.rest, d.psi, d.phi)
#
#     #c(t(apply(Z, 2, function(y) t(d.sigma) %*% W %*% vech(y %*% t(y) - sigma))))
#   }
# }
#
#
# sd = apply(HS.df, 2, sd)
# HS.df.standard = as.data.frame(t(apply(HS.df, 1, function(y) y/sd)))
#
# results <- m_estimate(
#     estFUN = estFUN.EM,
#     data = HS.df.standard,
#     roots = theta,
#     compute_roots = FALSE,
#     outer_args = list(constraints = constraints))
#
# CFA.se = sqrt(diag(vcov(results)))
#
# estimates = data.frame(
#       parameter = c(paste0('mu',1:9),
#                     paste0('lambda',10:18),
#                     paste0('psi',19:27),
#                     paste0('phi',28:30)),
#       est = theta,
#       se = CFA.se,
#       lower = theta - 1.96*CFA.se,
#       upper = theta + 1.96*CFA.se)
# estimates



#### PHQ 9 #####

library('foreign')
PHQ.df <- read.xport("~/Documents/research/Projects/REM_software/DPQ_J.XPT")

# replace 7 and 9 with NA
PHQ.df[PHQ.df == 7] <- NA
PHQ.df[PHQ.df == 9] <- NA

# remove missing data and drop last column
PHQ.df.complete <- PHQ.df[complete.cases(PHQ.df), 1-10]

# rename columns
names(PHQ.df.complete) <- c('id', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9')

## sample 1000 from this data set
#df <- PHQ.df.complete[sample(nrow(PHQ.df.complete), 1000, replace = F),]
df <- PHQ.df.complete

X = as.matrix(df[,-1])

EFA_out <- REM_EFA(X, 1:3)

PHQ_model <- 'z1 =~ x1 + x2 + x6 + x9
              z2 =~ x3 + x4 + x5 + x7 + x8'

PHQ.CFA.out <- REM_CFA(X, 2, model = PHQ_model, ctrREM = controlREM(steps = 10))

PHQ.df.complete$weights <- PHQ.CFA.out$REM_output$weights
aggregate(weights ~ x8, data = PHQ.df.complete, mean)
boxplot(PHQ.df.complete[,-1])

tic('robust SEs')
PHQ.se.robust <- SE(X, PHQ.CFA.out)
toc()
PHQ.se.robust


PHQ.lavaan.fit <- cfa(PHQ_model, data = df[,-1])
#summary(PHQ.lavaan.fit, standardized = T)$pe
standardizedSolution(PHQ.lavaan.fit)
# lhs op rhs est.std    se      z pvalue ci.lower ci.upper
# 1   z1 =~  x1   0.587 0.013 43.624      0    0.561    0.613
# 2   z1 =~  x2   0.759 0.010 74.219      0    0.739    0.779
# 3   z1 =~  x6   0.671 0.012 56.478      0    0.647    0.694
# 4   z1 =~  x9   0.647 0.012 52.466      0    0.623    0.671
# 5   z2 =~  x3   0.438 0.016 26.548      0    0.406    0.470
# 6   z2 =~  x4   0.515 0.015 33.318      0    0.484    0.545
# 7   z2 =~  x5   0.480 0.016 30.111      0    0.449    0.511
# 8   z2 =~  x7   0.569 0.015 38.789      0    0.540    0.598
# 9   z2 =~  x8   0.437 0.017 26.456      0    0.404    0.469
# 10  x1 ~~  x1   0.656 0.016 41.503      0    0.625    0.686
# 11  x2 ~~  x2   0.424 0.016 27.338      0    0.394    0.455
# 12  x6 ~~  x6   0.550 0.016 34.573      0    0.519    0.582
# 13  x9 ~~  x9   0.582 0.016 36.470      0    0.550    0.613
# 14  x3 ~~  x3   0.808 0.014 55.937      0    0.780    0.837
# 15  x4 ~~  x4   0.735 0.016 46.262      0    0.704    0.766
# 16  x5 ~~  x5   0.770 0.015 50.353      0    0.740    0.800
# 17  x7 ~~  x7   0.676 0.017 40.550      0    0.644    0.709
# 18  x8 ~~  x8   0.809 0.014 56.100      0    0.781    0.837
# 19  z1 ~~  z1   1.000 0.000     NA     NA    1.000    1.000
# 20  z2 ~~  z2   1.000 0.000     NA     NA    1.000    1.000
# 21  z1 ~~  z2   0.935 0.013 70.906      0    0.909    0.961


x1 = rnorm(n)
y = rbinom(n, 1, plogis(log(1.5)*x1))
df <- data.frame(y = y, x1 = x1)
m1 <- glm(y ~ x1, data = df, family = 'binomial')
boots <- replicate(1e3, {
  resample <- df[sample(nrow(df), nrow(df), replace = T), ]
  summary(glm(y ~ x1, data = resample, family = 'binomial'))$coef["x1", 1]
})
hist(boots)

# # simulated data
# n = 1500
# mu = c(.65, .53, .51, .55, .56, .36, .68, .78)
# lambda = matrix(data = c(.6, .7, .75, 0, 0, 0, 0, 0,
#                          0, 0, 0, .7, .5, .6, .3, .5), ncol = 2)
# psi = c(.5, .44, .4, .46, .45, .72, .41, .37)
# sigma = lambda %*% t(lambda) + diag(psi)
# X = mvrnorm(n, mu, sigma)
# X = as.data.frame(X)
#
# # standard.out <- factanal(X, 1)
# standard.out <- factanal(X, 2, rotation = 'oblimin')
# matrix(standard.out$loadings, ncol = 2)
# standard.out
#
# EFA.out <- REM_EFA(X, 2, rotation = 'oblimin', ctrREM = controlREM(steps = 10, tol = 1e-6))
# EFA.out[[1]]$EM_output$lambda
# summary(EFA.out)
#
#
# model = 'F1 ~ V1 + V2 + V3
#          F2 ~ V4 + V5 + V6 + V7 + V8'
# CFA.out <- REM_CFA(X, 2, model = model, ctrREM = controlREM(steps = 10, tol = 1e-6))
# summary(CFA.out)
#
# psych.out <- psych::fa(X, 3, fm = 'ml')
# psych.out


#
# if (type == 'bootstrap'){
#   boots <- replicate(1e2, {
#     resample <- X[sample(n, n, replace = T),]
#     refit.EM <- EMAlg(resample, k, constraints, rotation = 0, ctrREM)
#     mu1 = refit.EM$mu
#     lambda1 = refit.EM$lambda
#     psi1 = refit.EM$psi
#     phi1 = refit.EM$phi
#     refit.REM <- RobustEMAlg(resample, k, opt.eps, constraints, rotation = 0, mu1, lambda1, psi1, phi1, ctrREM)
#     as.numeric(c(
#       refit.EM$mu,
#       refit.EM$lambda[constraints==1],
#       refit.EM$psi,
#       refit.EM$phi[lower.tri(refit.EM$phi)],
#       refit.REM$mu,
#       refit.REM$lambda[constraints==1],
#       refit.REM$psi,
#       refit.REM$phi[lower.tri(refit.REM$phi)],
#       refit.REM$gamma))
#   })
#   # for EFA, I'll need to ensure factors are in the same order...
#
#   # reorient so all loadings point in same direction
#   boots.2 <- apply(boots, 2, function(x) abs(x) * sign(theta))
#   se = apply(boots.2, 1, sd)
# }


